package dev.daotlimbs.client;

import dev.daotlimbs.Limb;
import dev.daotlimbs.net.LimbNet;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Shown the first time you lose an eye: tap your face where the hollow should be. */
public class EyeSpotScreen extends Screen {
    private static final int PX = 22;                // screen pixels per face pixel
    private final int limb;
    private boolean sent;
    private int faceX, faceY;

    public EyeSpotScreen(int limb) {
        super(Text.literal("Hollow eye"));
        this.limb = limb;
    }

    @Override
    protected void init() {
        faceX = this.width / 2 - 4 * PX;
        faceY = this.height / 2 - 4 * PX + 10;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Your eye is gone."), this.width / 2, faceY - 34, 0xFF5555);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Tap your face where the hollow should be."), this.width / 2, faceY - 20, 0xFFFFFF);

        if (this.client != null && this.client.player != null) {
            PlayerSkinDrawer.draw(ctx, this.client.player.getSkinTextures(), faceX, faceY, 8 * PX);
        }
        if (inFace(mouseX, mouseY)) {                                   // preview of the black patch
            float[] c = spot(mouseX, mouseY);
            int x0 = faceX + Math.round((c[0] - 1f) * PX), x1 = faceX + Math.round((c[0] + 1f) * PX);
            int y0 = faceY + Math.round((c[1] - 1f) * PX), y1 = faceY + Math.round((c[1] + 1f) * PX);
            ctx.fill(x0, y0, x1, y1, 0xFF000000);
        }
    }

    private boolean inFace(double mx, double my) {
        return mx >= faceX && mx < faceX + 8 * PX && my >= faceY && my < faceY + 8 * PX;
    }

    private float[] spot(double mx, double my) {
        float px = (float) ((mx - faceX) / PX);
        float py = (float) ((my - faceY) / PX);
        return new float[]{Math.max(1f, Math.min(7f, px)), Math.max(1f, Math.min(7f, py))};
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && inFace(mouseX, mouseY)) {
            float[] c = spot(mouseX, mouseY);
            send(Math.round(c[0] * 10), Math.round(c[1] * 10));
            this.close();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void send(int x10, int y10) {
        if (sent) return;
        sent = true;
        ClientPlayNetworking.send(new LimbNet.EyeSpotPayload(limb, x10, y10));
    }

    @Override
    public void removed() {
        // closed without tapping: use the normal eye position
        if (!sent) {
            boolean left = limb == Limb.LEFT_EYE.ordinal();
            send(left ? 60 : 20, 50);
        }
        super.removed();
    }

    @Override
    public boolean shouldPause() { return false; }
}
