package dev.daotlimbs.client;

import dev.daotlimbs.net.LimbNet;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class DaotLimbsClient implements ClientModInitializer {
    private static KeyBinding regrowKey;

    @Override
    public void onInitializeClient() {
        regrowKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.daot_limbs.regrow", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.daot_limbs"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (regrowKey.wasPressed()) {
                if (client.player != null && client.currentScreen == null) {
                    ClientPlayNetworking.send(new LimbNet.OpenRequestPayload());
                }
            }
        });

        // lets the shared pose mixin ask the client who is lying down
        dev.daotlimbs.LimbRules.clientMask = e -> ClientLimbState.get(e.getId());

        FearClient.init();
        // E inside a Colossal Titan: don't open the inventory, burst out of the body instead
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            if (client.player == null || client.currentScreen != null) return;
            var vehicle = client.player.getVehicle();
            if (vehicle == null || !vehicle.getClass().getSimpleName().contains("Colossal")) return;
            while (client.options.inventoryKey.wasPressed()) {
                ClientPlayNetworking.send(new LimbNet.EjectPayload());
            }
        });
        net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry.register(dev.daotlimbs.scout.ScoutEntity.TYPE, ScoutEntityRenderer::new);
        ClientPlayNetworking.registerGlobalReceiver(LimbNet.FearPayload.ID,
                (payload, ctx) -> FearClient.start(payload.ticks()));

        ClientPlayNetworking.registerGlobalReceiver(LimbNet.SpotsPayload.ID,
                (payload, ctx) -> ClientLimbState.setSpots(payload.entityId(), payload.lx(), payload.ly(), payload.rx(), payload.ry()));

        ClientPlayNetworking.registerGlobalReceiver(LimbNet.EyeMenuPayload.ID,
                (payload, ctx) -> ctx.client().setScreen(new EyeSpotScreen(payload.limb())));

        // draws the black "hollow eye" patches on faces
        net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback.EVENT.register(
                (entityType, entityRenderer, registrationHelper, context) -> {
                    if (entityRenderer instanceof net.minecraft.client.render.entity.PlayerEntityRenderer pr) {
                        registrationHelper.register(new HollowEyeFeature(pr));
                    }
                });

        ClientPlayNetworking.registerGlobalReceiver(LimbNet.GrowPayload.ID,
                (payload, ctx) -> ClientLimbState.setGrow(payload.entityId(), payload.limb(), payload.progress()));

        ClientPlayNetworking.registerGlobalReceiver(LimbNet.SyncPayload.ID,
                (payload, ctx) -> ClientLimbState.put(payload.entityId(), payload.mask()));

        ClientPlayNetworking.registerGlobalReceiver(LimbNet.OpenMenuPayload.ID,
                (payload, ctx) -> ctx.client().setScreen(new LimbMenuScreen(payload.mask(), payload.hurt())));

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientLimbState.clear());
    }
}
