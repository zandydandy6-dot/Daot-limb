package dev.daotlimbs;

import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.function.ToIntFunction;

/** Shared flags: heal suppression, and the lying-down / kneeling state of players who lost their legs. */
public final class LimbRules {
    private LimbRules() {}

    /** True only while vanilla's hunger-based regeneration runs. */
    public static boolean suppressHeal = false;
    /** True only while OUR Hearts option heals someone. */
    public static boolean allowHeal = false;

    /** Extra bits in the synced limb mask (not persisted). */
    public static final int FALLEN_BIT = 1 << 6;   // lying flat on the ground
    public static final int KNEEL_BIT = 1 << 7;    // pushed up onto knees by the regrowing legs

    /** The client sets this to read limb state for any player entity. */
    public static ToIntFunction<Entity> clientMask = e -> 0;

    private static int mask(Entity e) {
        if (e.getWorld().isClient) return clientMask.applyAsInt(e);
        return e instanceof ServerPlayerEntity sp ? LimbManager.syncMask(sp) : 0;
    }

    public static boolean isFallen(Entity e) { return (mask(e) & FALLEN_BIT) != 0; }

    public static boolean isKneeling(Entity e) { return (mask(e) & KNEEL_BIT) != 0; }
}
