package dev.daotlimbs;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class LimbItems {
    private LimbItems() {}

    public static Item BANDAGE;

    public static void register() {
        BANDAGE = Registry.register(Registries.ITEM, Identifier.of(DaotLimbs.MOD_ID, "bandage"),
                new BandageItem(new Item.Settings().maxCount(16)));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> entries.add(BANDAGE));
    }
}
