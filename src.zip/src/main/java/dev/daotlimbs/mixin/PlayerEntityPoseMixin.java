package dev.daotlimbs.mixin;

import dev.daotlimbs.LimbRules;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Players who lost their legs are knocked flat: same pose, hitbox and model as crawling. */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityPoseMixin {
    @Inject(method = "updatePose", at = @At("TAIL"))
    private void daotlimbs$fall(CallbackInfo ci) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        if (self.hasVehicle()) return;
        if (LimbRules.isFallen(self)) self.setPose(EntityPose.SWIMMING);          // lying flat
        else if (LimbRules.isKneeling(self)) self.setPose(EntityPose.CROUCHING);   // pushed up onto knees
    }
}
