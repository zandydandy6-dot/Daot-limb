package dev.daotlimbs.mixin;

import dev.daotlimbs.IceRocks;
import dev.daotlimbs.LimbConfig;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Danny's AOT Beast Titan: snow/ice counts as rock ground; the carry ability turns into melting ice in ice biomes. */
@Mixin(targets = "daot.BeastTitanEntity", remap = false)
public abstract class BeastTitanMixin {
    @Inject(method = "isStoneGround", at = @At("RETURN"), cancellable = true, remap = false)
    private static void daotlimbs$iceIsGround(BlockState state, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue() && IceRocks.isIceGround(state)) cir.setReturnValue(true);
    }

    @Inject(method = "triggerBigRockGrab", at = @At("HEAD"), remap = false)
    private void daotlimbs$bigGrab(CallbackInfo ci) {
        if (LimbConfig.ICE_ABILITY2_IS_BIG_ROCK) IceRocks.onCarryAbility((Entity) (Object) this);
    }

    @Inject(method = "triggerFireRockGrab", at = @At("HEAD"), remap = false)
    private void daotlimbs$fireGrab(CallbackInfo ci) {
        if (!LimbConfig.ICE_ABILITY2_IS_BIG_ROCK) IceRocks.onCarryAbility((Entity) (Object) this);
    }
}
