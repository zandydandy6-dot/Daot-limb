package dev.daotlimbs;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

/** Three plain cube blocks used only as the look of regrowing flesh / bone / skin (textures sampled from DAOT's titan skins). */
public final class LimbBlocks {
    private LimbBlocks() {}

    public static Block FLESH;
    public static Block BONE;
    public static Block SKIN;

    public static void register() {
        FLESH = add("flesh_block", BlockSoundGroup.HONEY);
        BONE = add("bone_block", BlockSoundGroup.BONE);
        SKIN = add("skin_block", BlockSoundGroup.WOOL);
    }

    private static Block add(String name, BlockSoundGroup sounds) {
        return Registry.register(Registries.BLOCK, Identifier.of(DaotLimbs.MOD_ID, name),
                new Block(AbstractBlock.Settings.create().strength(0.5f).sounds(sounds)));
    }
}
