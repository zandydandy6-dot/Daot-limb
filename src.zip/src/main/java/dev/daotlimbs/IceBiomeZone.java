package dev.daotlimbs;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.chunk.WorldChunk;

import java.lang.reflect.Field;
import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Far beyond ALL the walls of Danny's AOT's Paradise dimension the land turns into an ice biome:
 * the biome source is told to answer with vanilla snowy / frozen biomes out there (snow falls, cold colours),
 * and chunks that load out there get their surface turned into snow and ice.
 */
public final class IceBiomeZone {
    private IceBiomeZone() {}

    /** how far past the outermost wall / district the ice begins (blocks) */
    private static final int MARGIN = 1500;

    private static volatile DynamicRegistryManager registries;
    private static volatile double startSq = -1;
    private static RegistryEntry<Biome> plains, peaks, spikes;

    private static final Deque<WorldChunk> QUEUE = new ArrayDeque<>();

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            registries = server.getRegistryManager();
            startSq = -1;
            plains = peaks = spikes = null;
        });
        ServerChunkEvents.CHUNK_LOAD.register((world, chunk) -> {
            if (isParadise(world) && isFar(chunk.getPos().getCenterX(), chunk.getPos().getCenterZ())
                    && !LimbData.flag(chunk, LimbData.ICE_DONE)) {
                synchronized (QUEUE) { QUEUE.add(chunk); }
            }
        });
        ServerTickEvents.END_SERVER_TICK.register(IceBiomeZone::tick);
    }

    private static boolean isParadise(ServerWorld w) {
        return w.getRegistryKey().getValue().equals(FirstSpawn.PARADIS);
    }

    /** squared distance from the Paradise city centre where the ice starts */
    private static double startSq() {
        double s = startSq;
        if (s >= 0) return s;
        double radius = 3000;
        try {
            Class<?> g = Class.forName("daot.world.ParadisChunkGenerator");
            try {
                Field f = g.getDeclaredField("WALL_OUTER_RADIUS");
                f.setAccessible(true);
                radius = Math.max(radius, f.getInt(null));
            } catch (Throwable ignored) { }
            int[][] centers = (int[][]) g.getMethod("getAllDistrictCenters").invoke(null);
            if (centers != null) {
                for (int[] c : centers) {
                    if (c != null && c.length >= 2) radius = Math.max(radius, Math.hypot(c[0], c[1]) + 400);
                }
            }
        } catch (Throwable t) {
            DaotLimbs.LOGGER.warn("[daot_limbs] ice zone: could not read the wall size ({}), using {} blocks", t.toString(), radius);
        }
        double edge = radius + MARGIN;
        startSq = edge * edge;
        DaotLimbs.LOGGER.info("[daot_limbs] ice biome starts {} blocks from the Paradise city centre", (int) edge);
        return startSq;
    }

    public static boolean isFar(double x, double z) {
        return x * x + z * z > startSq();
    }

    /** Called by the biome source mixin with biome (quart) coordinates. Null = keep Paradise's own biome. */
    public static RegistryEntry<Biome> biomeFor(int quartX, int quartZ) {
        double x = quartX * 4.0, z = quartZ * 4.0;
        if (!isFar(x, z)) return null;
        DynamicRegistryManager reg = registries;
        if (reg == null) return null;
        if (plains == null) {
            var r = reg.get(RegistryKeys.BIOME);
            plains = r.getEntry(BiomeKeys.SNOWY_PLAINS).map(e -> (RegistryEntry<Biome>) e).orElse(null);
            peaks = r.getEntry(BiomeKeys.FROZEN_PEAKS).map(e -> (RegistryEntry<Biome>) e).orElse(null);
            spikes = r.getEntry(BiomeKeys.ICE_SPIKES).map(e -> (RegistryEntry<Biome>) e).orElse(null);
        }
        // patchy: mostly snowy plains, with frozen peaks and ice spikes in blobs
        long h = (Math.floorDiv(quartX, 24) * 73856093L) ^ (Math.floorDiv(quartZ, 24) * 19349663L);
        int roll = (int) Math.floorMod(h, 10L);
        RegistryEntry<Biome> pick = roll == 0 ? peaks : (roll == 1 ? spikes : plains);
        return pick != null ? pick : plains;
    }

    // ---- turn the surface of far chunks into snow and ice, two chunks per tick ----

    private static void tick(MinecraftServer server) {
        for (int n = 0; n < 2; n++) {
            WorldChunk chunk;
            synchronized (QUEUE) { chunk = QUEUE.poll(); }
            if (chunk == null) return;
            if (LimbData.flag(chunk, LimbData.ICE_DONE) || !(chunk.getWorld() instanceof ServerWorld w)) continue;
            freeze(w, chunk);
            LimbData.setFlag(chunk, LimbData.ICE_DONE, true);
        }
    }

    private static void freeze(ServerWorld w, WorldChunk chunk) {
        int x0 = chunk.getPos().getStartX(), z0 = chunk.getPos().getStartZ();
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = x0 + dx, z = z0 + dz;
                int top = chunk.sampleHeightmap(Heightmap.Type.WORLD_SURFACE, x, z);      // first air above the surface
                BlockPos surface = new BlockPos(x, top - 1, z);
                BlockState s = w.getBlockState(surface);
                Block b = s.getBlock();
                if (b == Blocks.WATER) {
                    w.setBlockState(surface, Blocks.ICE.getDefaultState(), Block.NOTIFY_LISTENERS);
                } else if (isGround(s)) {
                    boolean rocky = ((x * 31 + z * 17) & 15) == 0;
                    w.setBlockState(surface, (rocky ? Blocks.PACKED_ICE : Blocks.SNOW_BLOCK).getDefaultState(), Block.NOTIFY_LISTENERS);
                    BlockPos below = surface.down();
                    if (isGround(w.getBlockState(below))) w.setBlockState(below, Blocks.SNOW_BLOCK.getDefaultState(), Block.NOTIFY_LISTENERS);
                    BlockPos above = surface.up();
                    if (w.getBlockState(above).isAir() && !rocky) w.setBlockState(above, Blocks.SNOW.getDefaultState(), Block.NOTIFY_LISTENERS);
                }
            }
        }
    }

    private static boolean isGround(BlockState s) {
        Block b = s.getBlock();
        return b == Blocks.GRASS_BLOCK || b == Blocks.DIRT || b == Blocks.COARSE_DIRT || b == Blocks.PODZOL || b == Blocks.MYCELIUM
                || b == Blocks.STONE || b == Blocks.SAND || b == Blocks.GRAVEL || b == Blocks.MUD || b == Blocks.ROOTED_DIRT
                || b == Blocks.ANDESITE || b == Blocks.GRANITE || b == Blocks.DIORITE || b == Blocks.TUFF || b == Blocks.DEEPSLATE
                || b == Blocks.COBBLESTONE || b == Blocks.MOSSY_COBBLESTONE;
    }
}
