package dev.daotlimbs;

import dev.daotlimbs.net.LimbNet;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The first time you get close to a titan your screen shakes a little and turns red, and you start begging
 * in chat. Every line is picked and dressed up at random, so it never sounds the same twice.
 */
public final class FearEvents {
    private FearEvents() {}

    private static final String[] BASE = {
            "I don't want to die",
            "help me",
            "someone, please",
            "please, please",
            "I'm scared",
            "mom, dad",
            "somebody help me",
            "I don't want to die, please",
            "please, I don't want to die",
            "mom... dad... I'm scared",
            "help me, please",
            "no, no, no... please"
    };

    /** uuid -> {ticks until the next line, lines left} */
    private static final Map<UUID, int[]> QUEUE = new HashMap<>();

    public static void tick(MinecraftServer server) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            int[] q = QUEUE.get(p.getUuid());
            if (q != null && --q[0] <= 0) {
                say(server, p);
                if (--q[1] <= 0) QUEUE.remove(p.getUuid());
                else q[0] = 14 + p.getRandom().nextInt(36);
            }

            if (p.age % 20 != 0 || p.isCreative() || p.isSpectator()) continue;
            if (LimbData.flag(p, LimbData.FEAR_SEEN)) continue;
            if (DaotBridge.titanOf(p) != null) continue;                 // you are the titan
            if (titanNear(p, server)) {
                LimbData.setFlag(p, LimbData.FEAR_SEEN, true);
                ServerPlayNetworking.send(p, new LimbNet.FearPayload(LimbConfig.FEAR_TICKS));
                QUEUE.put(p.getUuid(), new int[]{8, 4 + p.getRandom().nextInt(3)});
            }
        }
    }

    private static boolean titanNear(ServerPlayerEntity p, MinecraftServer server) {
        List<Entity> found = p.getWorld().getOtherEntities(p, p.getBoundingBox().expand(LimbConfig.FEAR_RANGE), e -> {
            if (!e.isAlive()) return false;
            if (DaotBridge.isPureTitan(e)) return true;
            if (DaotBridge.isShifterTitan(e)) {
                ServerPlayerEntity owner = DaotBridge.shifterOf(e, server);
                return owner == null || !owner.getUuid().equals(p.getUuid());
            }
            return false;
        });
        return !found.isEmpty();
    }

    private static void say(MinecraftServer server, ServerPlayerEntity p) {
        var r = p.getRandom();
        String line = BASE[r.nextInt(BASE.length)];
        // dress it up: stutter, trembling dots, shouting, or two cries in a row
        if (r.nextInt(4) == 0 && Character.isLetter(line.charAt(0))) line = line.charAt(0) + "-" + line;
        if (r.nextInt(5) == 0) line = line + " " + BASE[r.nextInt(BASE.length)];
        switch (r.nextInt(4)) {
            case 0 -> line = line + "...";
            case 1 -> line = line + "!";
            case 2 -> line = line.toUpperCase() + "!!";
            default -> { }
        }
        server.getPlayerManager().broadcast(Text.translatable("chat.type.text", p.getDisplayName(), Text.literal(line)), false);
    }

    public static void forget(UUID id) { QUEUE.remove(id); }
}
