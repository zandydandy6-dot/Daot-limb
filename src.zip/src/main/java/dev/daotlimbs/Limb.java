package dev.daotlimbs;

public enum Limb {
    LEFT_ARM(Group.ARM, "left arm"),
    RIGHT_ARM(Group.ARM, "right arm"),
    LEFT_LEG(Group.LEG, "left leg"),
    RIGHT_LEG(Group.LEG, "right leg"),
    LEFT_EYE(Group.EYES, "left eye"),
    RIGHT_EYE(Group.EYES, "right eye");

    public enum Group { ARM, LEG, EYES }

    public final Group group;
    public final String label;

    Limb(Group group, String label) {
        this.group = group;
        this.label = label;
    }

    public int bit() { return 1 << ordinal(); }
    public boolean isLeft() { return this == LEFT_ARM || this == LEFT_LEG || this == LEFT_EYE; }

    public static int maskOf(Group g) {
        int m = 0;
        for (Limb l : values()) if (l.group == g) m |= l.bit();
        return m;
    }

    public static final int ALL = (1 << 6) - 1;

    public static String describe(int mask) {
        StringBuilder sb = new StringBuilder();
        for (Limb l : values()) {
            if ((mask & l.bit()) != 0) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(l.label);
            }
        }
        return sb.length() == 0 ? "nothing" : sb.toString();
    }
}
