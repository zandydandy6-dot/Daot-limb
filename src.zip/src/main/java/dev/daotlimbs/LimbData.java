package dev.daotlimbs;

import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;

import java.util.List;

/** Persistent per-player bitmask of lost limbs (see {@link Limb#bit()}). Not copied on death: respawn = whole again. */
public final class LimbData {
    private LimbData() {}

    public static final AttachmentType<Integer> LOST = AttachmentRegistry.<Integer>builder()
            .persistent(Codec.INT)
            .initializer(() -> 0)
            .buildAndRegister(Identifier.of(DaotLimbs.MOD_ID, "lost"));

    public static int get(Entity e) {
        Integer v = e.getAttachedOrElse(LOST, 0);
        return v == null ? 0 : v;
    }

    public static void set(Entity e, int mask) {
        if (mask == 0) e.removeAttached(LOST);
        else e.setAttached(LOST, mask);
    }

    /** [leftEyeX*10, leftEyeY*10, rightEyeX*10, rightEyeY*10, menuShown]. Coordinates are on the 8x8-pixel face as the viewer sees it. */
    public static final List<Integer> DEFAULT_SPOTS = List.of(60, 50, 20, 50, 0);

    public static final AttachmentType<List<Integer>> EYE_SPOTS = AttachmentRegistry.<List<Integer>>builder()
            .persistent(Codec.INT.listOf())
            .copyOnDeath()
            .buildAndRegister(Identifier.of(DaotLimbs.MOD_ID, "eye_spots"));

    public static int[] spots(Entity e) {
        List<Integer> l = e.getAttachedOrElse(EYE_SPOTS, DEFAULT_SPOTS);
        int[] a = new int[5];
        for (int i = 0; i < 5; i++) a[i] = (l != null && l.size() > i) ? l.get(i) : DEFAULT_SPOTS.get(i);
        return a;
    }

    public static void setSpots(Entity e, int[] a) {
        e.setAttached(EYE_SPOTS, List.of(a[0], a[1], a[2], a[3], a[4]));
    }

    public static final AttachmentType<Boolean> FEAR_SEEN = AttachmentRegistry.<Boolean>builder()
            .persistent(Codec.BOOL).copyOnDeath()
            .buildAndRegister(Identifier.of(DaotLimbs.MOD_ID, "fear_seen"));

    public static final AttachmentType<Boolean> FIRST_SPAWN_DONE = AttachmentRegistry.<Boolean>builder()
            .persistent(Codec.BOOL).copyOnDeath()
            .buildAndRegister(Identifier.of(DaotLimbs.MOD_ID, "first_spawn_done"));

    public static final AttachmentType<Boolean> FIRST_TRANSFORM_DONE = AttachmentRegistry.<Boolean>builder()
            .persistent(Codec.BOOL).copyOnDeath()
            .buildAndRegister(Identifier.of(DaotLimbs.MOD_ID, "first_transform_done"));

    public static final AttachmentType<Boolean> ICE_DONE = AttachmentRegistry.<Boolean>builder()
            .persistent(Codec.BOOL)
            .buildAndRegister(Identifier.of(DaotLimbs.MOD_ID, "ice_done"));

    public static boolean flag(net.fabricmc.fabric.api.attachment.v1.AttachmentTarget e, AttachmentType<Boolean> t) {
        Boolean b = e.getAttachedOrElse(t, false);
        return b != null && b;
    }

    public static void setFlag(net.fabricmc.fabric.api.attachment.v1.AttachmentTarget e, AttachmentType<Boolean> t, boolean v) {
        e.setAttached(t, v);
    }

}
