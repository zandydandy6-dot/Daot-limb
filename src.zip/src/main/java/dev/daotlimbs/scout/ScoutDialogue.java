package dev.daotlimbs.scout;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.random.Random;

/** What the scouts say. Every scout gets a regiment and a personality at random, and talks accordingly. */
public final class ScoutDialogue {
    private ScoutDialogue() {}

    public enum Regiment {
        SURVEY("Survey Corps", "sc", Formatting.GREEN),
        GARRISON("Garrison", "gr", Formatting.GOLD),
        POLICE("Military Police", "mp", Formatting.DARK_GREEN);

        public final String title, code;
        public final Formatting color;
        Regiment(String title, String code, Formatting color) { this.title = title; this.code = code; this.color = color; }
    }

    /** 87% Eldian, 10% Ackerman, 3% royal. Nobody in Paradise is Marleyan. */
    public enum Bloodline {
        ELDIAN("Eldian"), ACKERMAN("Ackerman"), ROYAL("Royal");
        public final String title;
        Bloodline(String title) { this.title = title; }

        public static Bloodline roll(Random r) {
            int n = r.nextInt(100);
            return n < 3 ? ROYAL : (n < 13 ? ACKERMAN : ELDIAN);
        }
    }

    public enum Personality { BRAVE, COWARD, CHEERFUL, GRUMPY, CURIOUS, STOIC, HOTHEADED, KIND }

    private static final String[] FIRST = {
            "Aldric", "Marisol", "Tobias", "Lenka", "Ruben", "Haldis", "Jorin", "Elke", "Matthis", "Nora", "Felix", "Greta", "Anselm",
            "Ottilie", "Kasper", "Dorian", "Bastian", "Rhea", "Lukas", "Freya", "Hendrik", "Sabine", "Theo", "Wilma", "Emil",
            "Isolde", "Ivo", "Clara", "Joss", "Anika", "Osric", "Zora", "Milo", "Britta", "Roland", "Edda", "Silas", "Tilda",
            "Arne", "Liesel", "Nikolas", "Odette", "Pavel", "Runa", "Valerian", "Wanda", "Lorenz", "Maren", "Cassian", "Thea"
    };
    private static final String[] LAST = {
            "Brandt", "Keller", "Vogel", "Hartmann", "Falk", "Lindqvist", "Morrow", "Ashdown", "Weiss", "Halloran", "Dorn",
            "Maric", "Ostwald", "Rask", "Thorne", "Weller", "Zimmer", "Adler", "Bauer", "Ebel", "Grau", "Holt", "Sorel",
            "Wendt", "Ferrow"
    };

    public static String randomName(Random r) {
        String n = FIRST[r.nextInt(FIRST.length)];
        return r.nextInt(3) == 0 ? n : n + " " + LAST[r.nextInt(LAST.length)];
    }

    private static final String[][] CHAT = {
            /* BRAVE */ {
                    "Titans or not, I'm not turning back.", "Steady hands, steady heart. That is how I stay alive.",
                    "If we don't fight, who will?", "I'd rather die moving forward than standing still.",
                    "Stay behind me. I'll take the first swing.", "Fear is just a signal to aim better."},
            /* COWARD */ {
                    "Y-you think the walls will hold today?", "I check my gas three times every morning. Four, lately.",
                    "I only joined for the food. Seriously.", "Please tell me you saw nothing moving out there.",
                    "My hands won't stop shaking...", "If a titan shows up, I'm right behind you. Way behind."},
            /* CHEERFUL */ {
                    "Beautiful day to not be eaten!", "Want half my bread? I always make too much.",
                    "Smile! Even the walls look better with a smile.", "I heard there's stew tonight. Stew!",
                    "Good morning! Or afternoon. I lose track out here.", "We're alive, the sun is out. That's a win."},
            /* GRUMPY */ {
                    "What do you want?", "Keep your voice down. Titans have ears.", "Another day, another pointless drill.",
                    "My boots are soaked and my sergeant is a fool.", "Don't touch my gear.", "Ugh. Rations again."},
            /* CURIOUS */ {
                    "Have you ever wondered what's beyond the walls?", "Why do titans steam when they vanish? I have theories.",
                    "I keep notes on everything. Want to hear what I found?", "Do you know how ODM gear really works? Show me yours!",
                    "The sea... they say it's endless salt water. Imagine that.", "Every titan behaves a little differently. Fascinating."},
            /* STOIC */ {
                    "Hm.", "Orders are orders.", "Speak when you have something worth saying.", "I've seen worse.",
                    "Stay alert. That's all.", "The wall doesn't care how we feel about it."},
            /* HOTHEADED */ {
                    "Let them come! I'll cut every last one down!", "Don't tell me to calm down!",
                    "I'm sick of hiding behind a wall!", "Say that again, I dare you.", "Out of my way, I've got titans to kill!",
                    "I'll show the brass what I can do!"},
            /* KIND */ {
                    "Are you hurt? I have bandages.", "You look tired. Sit with me a moment.",
                    "Everyone out here is somebody's family. Remember that.", "Stay safe, alright? Promise me.",
                    "If you need anything, ask. I mean it.", "I'll watch your back, you watch mine."}
    };

    private static final String[][] ALARM = {
            /* BRAVE */ {"Titan! Form up, I'll hold it!", "Here they come! Steady!"},
            /* COWARD */ {"T-TITAN! RUN!", "No no no no, it's HERE!"},
            /* CHEERFUL */ {"Uh-oh! Big friend incoming! Everybody move!", "Titan! Let's not stay for tea!"},
            /* GRUMPY */ {"Damn it, titan. Move.", "Of course. Of course there's a titan."},
            /* CURIOUS */ {"Titan! Don't get too close... but look at its eyes!", "Incredible! And terrifying! Mostly terrifying!"},
            /* STOIC */ {"Titan. Fall back.", "Contact. Stay calm."},
            /* HOTHEADED */ {"FINALLY! Get over here, you ugly brute!", "Titan! Mine! All mine!"},
            /* KIND */ {"Titan! Get behind me, everyone, go!", "Run! I'll cover you!"}
    };

    private static final String[][] REGIMENT = {
            /* SURVEY */ {"We go where no one else dares. That's the Survey Corps.", "Eyes forward, blades ready!", "We chart the ground nobody else will walk."},
            /* GARRISON */ {"The walls don't guard themselves. Garrison duty never ends.", "Quiet watch tonight, thank the gods.", "Someone has to keep the gates."},
            /* POLICE */ {"The Military Police keeps order inside the walls. Papers, please.", "Keep your nose clean and we'll get along.", "The king's peace, citizen."}
    };

    private static final String[] ACKERMAN_LINES = {
            "My family has always been a bit... different in a fight. Nobody ever explains why.",
            "Sometimes my body just knows where the blow is coming from.",
            "People say Ackermans were hunted once. I'd like to see them try now."
    };
    private static final String[] ROYAL_LINES = {
            "There are whispers about my family line. I pretend not to hear.",
            "They say royal blood runs in my veins. I just want a quiet meal.",
            "Some people bow when they learn my name. It makes me deeply uncomfortable."
    };

    public static String chatLine(Regiment reg, Personality per, Bloodline blood, Random r) {
        if (blood == Bloodline.ACKERMAN && r.nextInt(5) == 0) return ACKERMAN_LINES[r.nextInt(ACKERMAN_LINES.length)];
        if (blood == Bloodline.ROYAL && r.nextInt(4) == 0) return ROYAL_LINES[r.nextInt(ROYAL_LINES.length)];
        return chatLine(reg, per, r);
    }

    public static String chatLine(Regiment reg, Personality per, Random r) {
        if (r.nextInt(4) == 0) {
            String[] rl = REGIMENT[reg.ordinal()];
            return rl[r.nextInt(rl.length)];
        }
        String[] l = CHAT[per.ordinal()];
        return l[r.nextInt(l.length)];
    }

    public static String alarmLine(Personality per, Random r) {
        String[] l = ALARM[per.ordinal()];
        return l[r.nextInt(l.length)];
    }

    /** Sends "<Name> line" (name in the regiment's colour) to one player. */
    public static void say(String name, Regiment reg, ServerPlayerEntity to, String line) {
        to.sendMessage(Text.literal("<").append(Text.literal(name).formatted(reg.color)).append(Text.literal("> " + line)), false);
    }
}
