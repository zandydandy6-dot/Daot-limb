package dev.daotlimbs;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/**
 * /daot shifter lose  <arm|leg|eyes> [left|right|both] [targets]
 * /daot shifter lose  head | all [targets]
 * /daot shifter regrow <arm|leg|eyes|all> [targets]     (instant, for testing; ignores the shifter requirement)
 * /daot shifter limbs [target]
 *
 * These register under DAOT's existing "daot shifter" node; Brigadier merges same-named literals.
 */
public final class LimbCommands {
    private LimbCommands() {}

    private static final String[] SIDES = {"left", "right", "both"};

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        LiteralArgumentBuilder<ServerCommandSource> lose = literal("lose");
        for (String part : new String[]{"arm", "leg", "eyes"}) {
            var node = literal(part).executes(c -> lose(c, part, "random", self(c)));
            for (String side : SIDES) {
                node.then(literal(side)
                        .executes(c -> lose(c, part, side, self(c)))
                        .then(argument("targets", EntityArgumentType.players())
                                .executes(c -> lose(c, part, side, EntityArgumentType.getPlayers(c, "targets")))));
            }
            lose.then(node);
        }
        lose.then(literal("head").executes(c -> head(c, self(c)))
                .then(argument("targets", EntityArgumentType.players()).executes(c -> head(c, EntityArgumentType.getPlayers(c, "targets")))));
        lose.then(literal("all").executes(c -> all(c, self(c)))
                .then(argument("targets", EntityArgumentType.players()).executes(c -> all(c, EntityArgumentType.getPlayers(c, "targets")))));

        LiteralArgumentBuilder<ServerCommandSource> regrow = literal("regrow");
        for (String part : new String[]{"arm", "leg", "eyes", "all"}) {
            regrow.then(literal(part).executes(c -> regrow(c, part, self(c)))
                    .then(argument("targets", EntityArgumentType.players()).executes(c -> regrow(c, part, EntityArgumentType.getPlayers(c, "targets")))));
        }

        LiteralArgumentBuilder<ServerCommandSource> limbs = literal("limbs").executes(c -> status(c, self(c)))
                .then(argument("targets", EntityArgumentType.players()).executes(c -> status(c, EntityArgumentType.getPlayers(c, "targets"))));

        LiteralArgumentBuilder<ServerCommandSource> eyemenu = literal("eyemenu").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            int[] sp = LimbData.spots(p);
            sp[4] = 0;
            LimbData.setSpots(p, sp);
            c.getSource().sendFeedback(() -> Text.literal("The next eye you lose opens the menu again."), false);
            return 1;
        });

        LiteralArgumentBuilder<ServerCommandSource> firstShift = literal("firsttransform").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            LimbData.setFlag(p, LimbData.FIRST_TRANSFORM_DONE, false);
            c.getSource().sendFeedback(() -> Text.literal("Your next transformation counts as your first again."), false);
            return 1;
        });

        d.register(literal("daot").then(literal("shifter").requires(s -> s.hasPermissionLevel(2))
                .then(lose).then(regrow).then(limbs).then(eyemenu).then(firstShift)));
    }

    private static Collection<ServerPlayerEntity> self(CommandContext<ServerCommandSource> c) throws CommandSyntaxException {
        return List.of(c.getSource().getPlayerOrThrow());
    }

    // ----- lose -----
    private static int lose(CommandContext<ServerCommandSource> c, String part, String side, Collection<ServerPlayerEntity> targets) {
        int n = 0;
        for (ServerPlayerEntity p : targets) {
            int bits = bitsFor(part, side, LimbData.get(p), p);
            if (bits != 0 && LimbManager.lose(p, bits)) n++;
        }
        final int count = n;
        c.getSource().sendFeedback(() -> Text.literal(count == 0 ? "Nothing to remove (already missing?)." : "Removed " + part + " (" + side + ") from " + count + " player(s)."), true);
        return n;
    }

    private static int bitsFor(String part, String side, int current, ServerPlayerEntity p) {
        Limb left, right;
        switch (part) {
            case "arm" -> { left = Limb.LEFT_ARM; right = Limb.RIGHT_ARM; }
            case "leg" -> { left = Limb.LEFT_LEG; right = Limb.RIGHT_LEG; }
            default -> { left = Limb.LEFT_EYE; right = Limb.RIGHT_EYE; }
        }
        switch (side) {
            case "both": return left.bit() | right.bit();
            case "left": return left.bit();
            case "right": return right.bit();
            default:
                List<Limb> intact = new ArrayList<>();
                if ((current & left.bit()) == 0) intact.add(left);
                if ((current & right.bit()) == 0) intact.add(right);
                return intact.isEmpty() ? 0 : intact.get(p.getRandom().nextInt(intact.size())).bit();
        }
    }

    private static int head(CommandContext<ServerCommandSource> c, Collection<ServerPlayerEntity> targets) {
        for (ServerPlayerEntity p : targets) LimbManager.loseHead(p);
        c.getSource().sendFeedback(() -> Text.literal("Beheaded " + targets.size() + " player(s)."), true);
        return targets.size();
    }

    private static int all(CommandContext<ServerCommandSource> c, Collection<ServerPlayerEntity> targets) {
        for (ServerPlayerEntity p : targets) LimbManager.lose(p, Limb.ALL);
        c.getSource().sendFeedback(() -> Text.literal("Removed all limbs and eyes from " + targets.size() + " player(s)."), true);
        return targets.size();
    }

    // ----- regrow (instant, debug) -----
    private static int regrow(CommandContext<ServerCommandSource> c, String part, Collection<ServerPlayerEntity> targets) {
        int bits = switch (part) {
            case "arm" -> Limb.maskOf(Limb.Group.ARM);
            case "leg" -> Limb.maskOf(Limb.Group.LEG);
            case "eyes" -> Limb.maskOf(Limb.Group.EYES);
            default -> Limb.ALL;
        };
        for (ServerPlayerEntity p : targets) LimbManager.restore(p, bits);
        c.getSource().sendFeedback(() -> Text.literal("Restored " + part + " on " + targets.size() + " player(s)."), true);
        return targets.size();
    }

    // ----- status -----
    private static int status(CommandContext<ServerCommandSource> c, Collection<ServerPlayerEntity> targets) {
        for (ServerPlayerEntity p : targets) {
            int m = LimbData.get(p);
            boolean shifter = DaotBridge.isShifter(p);
            boolean titan = DaotBridge.ridingTitan(p) != null;
            c.getSource().sendFeedback(() -> Text.literal(p.getName().getString() + ": missing " + Limb.describe(m)
                    + " | shifter=" + shifter + " | titan form=" + titan), false);
        }
        return targets.size();
    }
}
